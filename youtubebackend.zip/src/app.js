import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";

const app = express();
app.use(
  cors({
    origin: process.env.CORS_ORIGIN,
    credentials: true,
  })
);
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(cookieParser());

//import routes
import userRouter from "./routes/user.router.js";

//use routes
app.use("/api/users", userRouter);

// app.post("/api/test", (req, res) => {
//   console.log(req.cookies);
//   res.status(200).json({ message: "Hello from server!" });
// });
export default app;
